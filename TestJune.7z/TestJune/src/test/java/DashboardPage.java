import org.checkerframework.checker.nullness.qual.Nullable;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import static org.testng.AssertJUnit.assertEquals;

public class DashboardPage {

    private By XPATH_DASHBOARD_TITLE = By.xpath("//*[@id='content']/h1");
    private By XPATH_BLOG_ENTRIES_TITLE_ADD = By.xpath("//*[@id='module_2']/div/ul[1]/li[1]/ul/li[1]/a");
    private By XPATH_EDIT_ENTRY_BUTTON = By.xpath("//*[@id='module_2']/div/ul[1]/li[1]/ul/li[2]/a");

    private WebElement addBtn;

    private int timeout;
    private WebElement titleH1;
    private WebElement editEntryBtn;

    public DashboardPage(int timeout) throws Exception {
        this.timeout = timeout;
    }

    private WebElement waitForElementVisible (By xpathElement, WebDriver webDriver, int timeout) throws Exception {
        WebElement element = (new WebDriverWait(webDriver, timeout)).until(new ExpectedCondition<WebElement>() {
            @Override
            public @Nullable WebElement apply(@Nullable WebDriver webDriver) {
                return webDriver.findElement(xpathElement);
            }
        });
        return element;
    }

    public DashboardPage checkTitle(WebDriver webDriver) throws Exception {
        this.titleH1 = webDriver.findElement(XPATH_DASHBOARD_TITLE);
        String titleActual = titleH1.getText();
        String titleExpected = "Панель управления";
        assertEquals("Wrong title!", titleExpected, titleActual);
        return this;
    }

    public DashboardPage clickAddBtn (WebDriver webDriver) throws Exception {
        //this.addBtn = webDriver.findElement(XPATH_BLOG_ENTRIES_TITLE_ADD);
        waitForElementVisible(XPATH_BLOG_ENTRIES_TITLE_ADD, webDriver, timeout).click();
        return this;
    }

    public DashboardPage clickEditEntryBtn (WebDriver webDriver) throws Exception {
        waitForElementVisible(XPATH_EDIT_ENTRY_BUTTON, webDriver, timeout).click();
        return this;
    }

}
