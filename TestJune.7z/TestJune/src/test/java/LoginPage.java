import org.checkerframework.checker.nullness.qual.Nullable;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage {

    private final WebDriver driver = new ChromeDriver();

    private final By XPATH_USERNAME_FIELD = By.xpath("//*[@id='id_username']");
    private final By XPATH_PASSWORD_FIELD = By.xpath("//*[@id='id_password']");
    private final By XPATH_SUBMIT_BUTTON = By.xpath("//*['login-form']/div[3]/input");

    private int timeout;

    private WebElement weUserName;
    private WebElement wePassword;
    private WebElement weSubmitBtn;

    private WebElement waitForElementVisible (By xpathElement, WebDriver webDriver, int timeout) throws Exception {
        WebElement element = (new WebDriverWait(webDriver, timeout)).until(new ExpectedCondition<WebElement>() {
            @Override
            public @Nullable WebElement apply(@Nullable WebDriver webDriver) {
                return webDriver.findElement(xpathElement);
            }
        });
        return element;
    }

    public LoginPage clearFields (WebDriver webDriver) throws Exception {
        //this.weUserName = webDriver.findElement(XPATH_USERNAME_FIELD);
        waitForElementVisible(XPATH_USERNAME_FIELD, webDriver, timeout).clear();

        //this.wePassword = webDriver.findElement(XPATH_PASSWORD_FIELD);
        waitForElementVisible(XPATH_PASSWORD_FIELD, webDriver, timeout).clear();

        return this;
    }

    public LoginPage fillOutLoginFields (String textName, String textPassword, WebDriver webDriver) throws Exception {
        //this.weUserName = webDriver.findElement(XPATH_USERNAME_FIELD);
        waitForElementVisible(XPATH_USERNAME_FIELD, webDriver, timeout).sendKeys(textName);

        //this.wePassword = webDriver.findElement(XPATH_PASSWORD_FIELD);
        waitForElementVisible(XPATH_PASSWORD_FIELD, webDriver, timeout).sendKeys(textPassword);

        return this;
    }

    public LoginPage clickLoginBtn (WebDriver webDriver) throws Exception {
        waitForElementVisible(XPATH_SUBMIT_BUTTON, webDriver, timeout).click();
        return this;
    }

}
