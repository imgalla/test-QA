import org.checkerframework.checker.nullness.qual.Nullable;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

public class EditEntriesPage {

    List<WebElement> entries;
    String entryXpath;
    private int timeout;

    public EditEntriesPage (int timeout) throws Exception {
        this.timeout = timeout;
    }

    private WebElement waitForElementVisible (By xpathElement, WebDriver webDriver, int timeout) throws Exception {
        WebElement element = (new WebDriverWait(webDriver, timeout)).until(new ExpectedCondition<WebElement>() {
            @Override
            public @Nullable WebElement apply(@Nullable WebDriver webDriver) {
                return webDriver.findElement(xpathElement);
            }
        });
        return element;
    }

    public EditEntriesPage findMyEntry (WebDriver webDriver, String titleEntry) throws Exception {

        List<WebElement> titleElements = webDriver.findElements(By.xpath("//th/a"));
        //System.out.println("The number of titles is: "+titleElements.size());

        List<WebElement> checkBoxes = webDriver.findElements(By.xpath("//*[@class='action-select']"));
        //System.out.println("The number of checkboxes is: " + checkBoxes.size());

        WebElement selectOptionField = webDriver.findElement(By.xpath("//*[@id='changelist-form']/div[2]/label/select/option[2]"));
        WebElement deleteButton = webDriver.findElement(By.xpath("//*[@id='changelist-form']/div[2]/button"));

        String[] textsOfTitles = new String[titleElements.size()];
        int j = 0;
        for (WebElement e : titleElements) {
            textsOfTitles[j] = e.getText();
           //System.out.println("textsOfTitles[j] = " + textsOfTitles[j]);
            if (textsOfTitles[j].equals(titleEntry)) {
                checkBoxes.get(j).click();
                selectOptionField.click();
                deleteButton.click();
            }
            j++;
        }

        return this;
    }

    public EditEntriesPage deleteMyEntry (WebDriver webDriver) throws Exception {

        WebElement confirmDeleteButton = webDriver.findElement(By.xpath("//*[@id='content']/form/div/input[4]"));

        confirmDeleteButton.click();

        return this;

    }
}
