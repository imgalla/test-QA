import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Main {

    //public static BlogAddEntryPage theLastGeneratedTitle;
    public static void main(String[] args) throws Exception {

        System.setProperty("webdriver.chrome.driver", "C:\\Users\\user\\IdeaProjects\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();

        driver.get("https://igorakintev.ru/admin/");

        LoginPage loginPage = new LoginPage();
        loginPage.clearFields(driver)
                .fillOutLoginFields("selenium", "super_password", driver)
                .clickLoginBtn(driver);

        DashboardPage dashboardPage = new DashboardPage(10);
        dashboardPage.checkTitle(driver).clickAddBtn(driver);

        BlogAddEntryPage blogAddEntryPage = new BlogAddEntryPage(10);
        blogAddEntryPage.checkTitle(driver)
                .clearAndFillOutFieldsRandomly(driver)
                .clickSaveBtn(driver);

        driver.get("https://igorakintev.ru/blog/");

        BlogPage blogPage = new BlogPage(10);

        String titleExpected = blogAddEntryPage.set_title();
        System.out.println("titleExpected in Main = " + titleExpected);
        BlogPage.checkPresenceOfTheTitle(driver, titleExpected);

        driver.get("https://igorakintev.ru/admin/");

        dashboardPage.clickEditEntryBtn(driver);

        EditEntriesPage editEntriesPage = new EditEntriesPage(10);
        editEntriesPage.findMyEntry(driver, titleExpected);
        editEntriesPage.deleteMyEntry(driver);

    }
}
