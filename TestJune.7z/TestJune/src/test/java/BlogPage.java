import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import static org.testng.AssertJUnit.assertEquals;

public class BlogPage {

    private int timeout;

    public BlogPage(int timeout) throws Exception {
        this.timeout = timeout;
    }

    public static void checkPresenceOfTheTitle (WebDriver webDriver, String titleExpected) throws Exception {
        By XPATH_ENTRY_TITLE = By.xpath("//*[@id='entries']/h2[1]/a");
        WebElement entryTitle = webDriver.findElement(XPATH_ENTRY_TITLE);
        String titleActual = entryTitle.getText();
        assertEquals("Wrong title!", titleExpected, titleActual);
    }
}
