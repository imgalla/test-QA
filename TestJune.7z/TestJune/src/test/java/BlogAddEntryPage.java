import org.apache.commons.lang3.RandomStringUtils;
import org.checkerframework.checker.nullness.qual.Nullable;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import static org.testng.AssertJUnit.assertEquals;

public class BlogAddEntryPage {

    private By XPATH_ADD_ENTRY_PAGE_TITLE = By.xpath("//*[@id='content']/h1");
    private By XPATH_TITLE_FIELD = By.xpath("//*[@id='id_title']");
    private By XPATH_SLUG_FIELD = By.xpath("//*[@id='id_slug']");
    private By XPATH_MARKDOWN_FIELD = By.xpath("//*[@id='id_text_markdown']");
    private By XPATH_TEXT_FIELD = By.xpath("//*[@id='id_text']");
    private By XPATH_SAVE_BUTTON = By.xpath("//*[@id='entry_form']/div/div/input[1]");

    private int timeout;

    private WebElement pageTitleH1;
    private WebElement titleField;
    private WebElement slugField;
    private WebElement markdownTextField;
    private WebElement textField;
    private WebElement saveButton;

    public String lastTitle;

    public BlogAddEntryPage(int timeout) throws Exception {
        this.timeout = timeout;
    }

    private WebElement waitForElementVisible (By xpathElement, WebDriver webDriver, int timeout) throws Exception {
        WebElement element = (new WebDriverWait(webDriver, timeout)).until(new ExpectedCondition<WebElement>() {
            @Override
            public @Nullable WebElement apply(@Nullable WebDriver webDriver) {
                return webDriver.findElement(xpathElement);
            }
        });
        return element;
    }

    public BlogAddEntryPage checkTitle(WebDriver webDriver) throws Exception {
        this.pageTitleH1 = webDriver.findElement(XPATH_ADD_ENTRY_PAGE_TITLE);
        String titleActual = pageTitleH1.getText();
        String titleExpected = "Добавить entry";
        assertEquals("Wrong title!", titleExpected, titleActual);
        return this;
    }

    public BlogAddEntryPage clearAndFillOutFieldsRandomly (WebDriver webDriver) throws Exception {

        this.titleField = webDriver.findElement(XPATH_TITLE_FIELD);
        waitForElementVisible(XPATH_TITLE_FIELD, webDriver, timeout).clear();
        String generateTitle = RandomStringUtils.randomAlphanumeric(10);
        lastTitle = "title" + generateTitle;
        System.out.println("lastTitle = " + lastTitle);
        titleField.sendKeys(lastTitle);

        this.slugField = webDriver.findElement(XPATH_SLUG_FIELD);
        waitForElementVisible(XPATH_SLUG_FIELD, webDriver, timeout).clear();
        String generateSlug = RandomStringUtils.randomAlphanumeric(10);
        slugField.sendKeys("slug" + generateSlug);

        this.markdownTextField = webDriver.findElement(XPATH_MARKDOWN_FIELD);
        waitForElementVisible(XPATH_MARKDOWN_FIELD, webDriver, timeout).clear();
        String generateMarkdownText = RandomStringUtils.randomAlphanumeric(15);
        markdownTextField.sendKeys("markdown" + generateMarkdownText);

        this.textField = webDriver.findElement(XPATH_TEXT_FIELD);
        waitForElementVisible(XPATH_TEXT_FIELD, webDriver, timeout).clear();
        String generateText = RandomStringUtils.randomAlphanumeric(15);
        textField.sendKeys("text" + generateText);

        return this;
    }

    public String set_title() {
        String titleExpected = lastTitle;
        System.out.println("lastTitle in set_title() = " + lastTitle);
        return titleExpected;
    }


    public BlogAddEntryPage clickSaveBtn (WebDriver webDriver) throws Exception {
        waitForElementVisible(XPATH_SAVE_BUTTON, webDriver, timeout).click();
        return this;
    }
}
